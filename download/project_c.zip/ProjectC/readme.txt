
                           -=Project Cataclysm 1.1=-
	                  by Erik Moberg AKA Raccoon

"Much good work is lost for the lack of a little more."
 --Edward Harriman

This is non-commercial software, coded in C++ with help from the Allegro Library. 
Give it to your friends, your family, your dog or whoever you like.

Disclaimer: This software is provided "as is" without any warranty whatsoever... 
I will not take responsibility for any damage, direct or indirect, caused by this 
software. Use at your own risc.

Story:
Eh...some bad guys are trying to take over the world. You are Seppo. You have a big 
gun. Get rid of the bad guys.

I will not even try to come up with an explanation to who that other guy is, who is
helping you in co-op-mode, or trying to kill you in deathmatch-mode... nor will I
attempt to explain why you can get killed five times.

Features:

 - Ten exciting levels
 - Three game-styles: Single Player, Multiplayer Cooperative an Multiplayer Deathmatch
 - Two realistic weapons, plus grenades
 - Marks on walls
 - Authentic sound effects
 - Highly advanced AI
 - A really deep storyline
 - Mind-blowing graphics 

(Oops...got a little carried away.)

General Info:

Project Cataclysm is a simple, but yet entertaining game. It features ten levels, 
that can be played in three different modes: Single player, Multiplayer
Cooperative, or Multiplayer Deathmatch.
There are two different weapons in the game; the famous submachinegun H&K MP5, and 
the automatic shotgun SPAS-12. The MP5 can load 30 9mm bullets at a time, the SPAS-12
7 12-gauge (buckshot).
Grenades are also available. Throw them and watch them bounce against walls and floors,
and then explode after three seconds. Grenades also explodes instantly upon contact
with an enemy. Use grenades with caution though; if you are too near one when it 
explodes, you will most likely get killed.
The enemies use both guns, but not grenades.
Note that being hit by a grenade does not necessarily lead to an unpleasant death. 
The longer you are in the splash radius of the grenade, the more damage you will take.
An enemy with a lot of health may survive a direct hit. But since you don't have any
health at all... the chance of survival is zero if you get in the splash radius.

In the root directory, you will find a file called "config.cfg". Here, your settings 
regarding sound, music, controls, and weapons are saved. If you accidentaly mess your 
settings up, just delete this file. A new one will be created with the default settings.

What's new in v1.1?

 - Added vertical walls
 - Updated most of the maps
 - You can now reload whenever you want (the clip must not be full, however)
 - The bullets from the MP5 now spread out
 - Added difficulty now showing up in the outro
 - The SPAS-12 now only holds 7 shells
 - Added a "Really Quit?" dialogue box
 - Updated AI (to make it react well to vertical walls)
 - Updated the way grenades work (for the same reason)
 - Made the code look a little better

Default key bindings:
 Player 1:
  Jump		Arrow up
  Move left	Arrow left
  Move right	Arrow right
  Move down	Arrow down
  Fire		Space
  Throw grenade	Enter
  Reload	' (the key next to Enter)

 Player 2:
  Jump		R
  Move left	D
  Move right	G
  Move down	F
  Fire		W
  Throw grenade	Q
  Reload	A

Knows issues:

The sound is not working well on every system. This depends on your OS, hardware, 
drivers, and... this game. The sound is not likely to work at all on NT-systems.
If your sound is bad, just turn it off. I really don't have any other solution to this.

You can redefine the keys, but you can not use all the keys on your keyboard. Keys like
SHIFT, ALT and CTRL do simply not work. And if you intend to use keys on the numpad, be 
sure to turn NUMLOCK off. Otherwise, they won't but not work at all in the game. 
(When redefying the keys, they will respond, however.)

Only a limited number of keypresses can be detected at a time. This is _not_ a software 
bug, but a problem with the keyboard. Different keyboards can detect different numbers of 
keypresses simultaneously.

The game may run a little slow on some NT-machines. The game runs fine on a P166MMX 
(32Mb RAM) running Win98, but on a PIII-500 (128Mb RAM) running NT, the performance is 
pretty slow. Can't do much about this, though - NT is NT, right?

The game is not likely to run under Windows 2000, but works decently under XP.

Grenades get stuck sometimes. But not often enough to affect gameplay.

Credits:

Pictures of the bad guys from http://www.teletubbies.com
Some sound effects from Quake III Arena by Id Software
Menu music from Id Softwares Doom II
Some more sound effects from Tom Clancy's Rainbow Six: Rouge Spear
A few more sounds from Tetris 4000
Intromusic (The Cardigans - My favourite Game) and in-game music (Hot Butter - Popcorn) 
from Tetris 4000 
The "Boing"-like sound when jumping is from Carmageddon II: Carpocalypse Now by Stainless
Interactive (original filename is "boing!.wav")
Background pictures from Counter-Strike, a Half-Life mod (www.counter-strike.net)
All this without permission...

Thanks to Anders Andersson, who has helped me get it right from the beginning with this 
project - the code would probably look even worse if it wasn't for you!

My teacher, Fredrik B�ckman, has helped me a lot. I say thanks, but...it's your job to 
help me. :-)

Also thanks to Sam Skoglund, who has given me feedback on this game, and looked all over
for bugs... and there was a lot of them, to say the least.

I would also like to thank Shawn Hargreaves for the excellent programming library
     ______   ___    ___
    /\  _  \ /\_ \  /\_ \
    \ \ \L\ \\//\ \ \//\ \      __     __   _ __   ___ 
     \ \  __ \ \ \ \  \ \ \   /'__`\ /'_ `\/\`'__\/ __`\
      \ \ \/\ \ \_\ \_ \_\ \_/\  __//\ \L\ \ \ \//\ \L\ \
       \ \_\ \_\/\____\/\____\ \____\ \____ \ \_\\ \____/
        \/_/\/_/\/____/\/____/\/____/\/___L\ \/_/ \/___/
                                       /\____/
                                       \_/__/
  
And, of course, last but not least, I would like to thank Microsoft for the excellent 
product Notepad. 
(However... not even this piece of software was free from bugs. Sometimes the cursor is 
at two places at the same time...)

Drop a line...
erikmoberg@hotmail.com