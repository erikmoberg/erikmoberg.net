Help and updates:

http://www.erikmoberg.net/jpegrotator.php